var searchData=
[
  ['getadjacentaxis_0',['getAdjacentAxis',['../classColumn.html#ac3f4192ea35b7a163cdb127db5b39d0e',1,'Column']]],
  ['getx_1',['getX',['../classColumn.html#a08cca63f286486e18536c7a277260eeb',1,'Column']]],
  ['gety_2',['getY',['../classColumn.html#ab7d6d7207c69561677137bdf96280f77',1,'Column']]],
  ['getz_3',['getZ',['../classColumn.html#a019e82c493a63de13526cf959d2611f6',1,'Column']]]
];
