var searchData=
[
  ['column_0',['Column',['../classColumn.html',1,'']]],
  ['columndata_1',['ColumnData',['../structColumnData.html',1,'']]]
];
