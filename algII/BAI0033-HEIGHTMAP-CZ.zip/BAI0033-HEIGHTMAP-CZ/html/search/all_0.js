var searchData=
[
  ['addadjacent_0',['addAdjacent',['../classColumn.html#aba38ae398ddaa873adfe24c05ee05fcd',1,'Column']]],
  ['adjfaces_1',['adjFaces',['../structColumnData.html#ac3bdaf358ae118e24410f08cdd6b3997',1,'ColumnData']]]
];
