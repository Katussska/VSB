var searchData=
[
  ['addadjacent_0',['addAdjacent',['../classColumn.html#aba38ae398ddaa873adfe24c05ee05fcd',1,'Column']]]
];
