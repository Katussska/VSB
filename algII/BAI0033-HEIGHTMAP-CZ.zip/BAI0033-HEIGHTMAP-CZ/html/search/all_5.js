var searchData=
[
  ['setchecked_0',['setChecked',['../classColumn.html#a49d2fa33e7c912ea068c139a3ce17ec3',1,'Column']]]
];
