var searchData=
[
  ['obstruction_0',['obstruction',['../structColumnData.html#ad7a0a5ce3af328c9c39b10a41622e018',1,'ColumnData']]]
];
