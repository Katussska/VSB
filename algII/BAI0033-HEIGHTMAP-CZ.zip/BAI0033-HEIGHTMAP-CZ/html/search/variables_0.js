var searchData=
[
  ['adjfaces_0',['adjFaces',['../structColumnData.html#ac3bdaf358ae118e24410f08cdd6b3997',1,'ColumnData']]]
];
