CREATE TRIGGER TCHANGECOURSECAPACITY
    BEFORE UPDATE
    ON COURSE
    FOR EACH ROW
DECLARE
    studentsCount integer;
    e_no_change EXCEPTION;
BEGIN
    IF (:NEW.Capacity < :OLD.Capacity) THEN
        SELECT COUNT(*)
        INTO studentsCount
        FROM studentcourse
        WHERE course_code = :NEW.code AND (points IS NULL OR points < 51);
        IF (studentsCount > :NEW.Capacity) THEN
            RAISE e_no_change;
        END IF;
    ELSIF (:NEW.Capacity > :OLD.Capacity) THEN
        studentsCount := :NEW.Capacity - :OLD.Capacity;
        FOR student IN (SELECT login
                        FROM student
                        WHERE grade = :NEW.grade
                          AND login NOT IN (SELECT login
                                            FROM studentcourse
                                            WHERE course_code = :NEW.code)
                        ORDER BY lname ASC)
            LOOP
                INSERT INTO studentcourse (student_login, course_code, year, points)
                VALUES (student.login, :NEW.code, EXTRACT(YEAR FROM CURRENT_TIMESTAMP), 0);
                studentsCount := studentsCount - 1;
                IF (studentsCount = 0) THEN
                    EXIT;
                END IF;
            END LOOP;
    END IF;
EXCEPTION
    WHEN e_no_change THEN
        dbms_output.put_line('Error');
        RAISE;
END;
/

