CREATE PROCEDURE PMoveToNextGrade AS
    v_nextGrade INT;
BEGIN
    FOR c_student IN (SELECT login FROM Student ORDER BY grade DESC)
        LOOP
            IF FAllSubjectsPass(c_student.login) THEN
                v_nextGrade := FNextGrade(c_student.login);

                UPDATE Student
                SET grade = v_nextGrade
                WHERE login = c_student.login;

                PSetFreeCourses(c_student.login);
            END IF;
        END LOOP;
END;
/

