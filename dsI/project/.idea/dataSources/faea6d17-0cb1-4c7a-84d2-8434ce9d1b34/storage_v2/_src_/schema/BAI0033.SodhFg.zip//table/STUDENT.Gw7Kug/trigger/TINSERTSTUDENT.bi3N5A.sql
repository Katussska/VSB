CREATE TRIGGER TINSERTSTUDENT
    AFTER INSERT
    ON STUDENT
    FOR EACH ROW
BEGIN
    PPrint(:new.login || ': ' || :new.fname || ' ' || :new.lname);
END;
/

