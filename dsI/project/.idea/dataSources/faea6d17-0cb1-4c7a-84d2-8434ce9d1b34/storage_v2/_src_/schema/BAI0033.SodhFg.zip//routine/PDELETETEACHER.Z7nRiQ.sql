CREATE PROCEDURE PDeleteTeacher(p_login Teacher.login%TYPE) AS
    v_teacherLogin  Teacher.login%TYPE;
    v_otherTeachers INT;
    v_noOtherTeacher EXCEPTION;
BEGIN
    SELECT COUNT(*)
    INTO v_otherTeachers
    FROM Teacher
    WHERE login <> p_login;

    IF v_otherTeachers = 0 THEN
        RETURN;
    END IF;

    SELECT Teacher.login
    INTO v_teacherLogin
    FROM Teacher
             LEFT JOIN Course ON Teacher.login = Course.teacher_login
    WHERE Teacher.login <> p_login
    GROUP BY Teacher.login
    ORDER BY COUNT(Course.code)
        FETCH FIRST 1 ROWS ONLY;

    UPDATE Course
    SET teacher_login = v_teacherLogin
    WHERE teacher_login = p_login;

    DELETE
    FROM Teacher
    WHERE login = p_login;

    COMMIT;

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
END;
/

