CREATE PROCEDURE PAddStudent1(p_login Student.login%TYPE, p_fname Student.fname%TYPE,
                                         p_lname Student.lname%TYPE,
                                         p_email Student.email%TYPE, p_grade Student.grade%TYPE,
                                         p_dateOfBirth Student.date_of_birth%TYPE) AS
BEGIN
    INSERT INTO Student (login, fname, lname, email, grade, date_of_birth)
    VALUES (p_login, p_fname, p_lname, p_email, p_grade, p_dateOfBirth);
END;
/

