CREATE FUNCTION FAllSubjectsPass(p_login Student.login%TYPE) RETURN BOOLEAN AS
    v_grade Student.grade%TYPE;
    v_cnt   INT;
BEGIN
    SELECT grade
    INTO v_grade
    FROM Student
    WHERE login = p_login;

    SELECT COUNT(*)
    INTO v_cnt
    FROM Course
             LEFT JOIN StudentCourse
                       ON Course.code = StudentCourse.course_code AND StudentCourse.student_login = p_login
    WHERE grade = v_grade
      AND COALESCE(StudentCourse.points, 0) < 51;

    IF v_cnt > 0 THEN
        RETURN FALSE;
    ELSE
        RETURN TRUE;
    END IF;
END;
/

