CREATE PROCEDURE PAwardStudents(p_year INT, p_amount NUMBER) AS
    v_i      INT    := 0;
    v_amount NUMBER := p_amount;
BEGIN
    FOR c_student IN (
        SELECT student_login, SUM(points) AS pts
        FROM StudentCourse
        WHERE year = p_year
        GROUP BY student_login
        ORDER BY pts DESC
        )
        LOOP
            EXIT WHEN v_i >= 5;

            UPDATE Student
            SET account_balance = account_balance + v_amount
            WHERE login = c_student.student_login;

            v_amount := v_amount / 2;
            v_i := v_i + 1;
        END LOOP;
END;
/

