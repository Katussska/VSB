CREATE FUNCTION FNextGrade(p_login Student.login%TYPE) RETURN INT AS
    v_currentGrade Student.grade%TYPE;
BEGIN
    SELECT grade
    INTO v_currentGrade
    FROM Student
    WHERE login = p_login;

    IF v_currentGrade < 5 THEN
        RETURN v_currentGrade + 1;
    ELSE
        RETURN -1;
    END IF;
END;
/

