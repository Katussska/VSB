CREATE PROCEDURE PPrepareTableReward AS
    v_cnt INT;
BEGIN
    SELECT COUNT(*)
    INTO v_cnt
    FROM user_tables
    WHERE table_name = 'REWARD';

    IF v_cnt > 0 THEN
        EXECUTE IMMEDIATE ('DROP TABLE Reward');
    END IF;

    EXECUTE IMMEDIATE ('
CREATE TABLE Reward
(
    id INTEGER PRIMARY KEY,
    student_login CHAR(6) REFERENCES Student,
    winter_reward INTEGER NULL,
    summer_reward INTEGER NULL,
    thesis_reward INTEGER NULL
)');
END;
/

