CREATE PROCEDURE PCheckStudents(p_amount NUMBER) AS
    v_avgPts NUMBER;
BEGIN
    SELECT AVG(sum_points)
    INTO v_avgPts
    FROM (SELECT SUM(points) AS sum_points
          FROM StudentCourse
          GROUP BY student_login) T;

    UPDATE Student
    SET account_balance = account_balance + p_amount
    WHERE (SELECT SUM(points)
           FROM StudentCourse
           WHERE StudentCourse.student_login = Student.login) > v_avgPts;

    UPDATE Student
    SET account_balance = account_balance - p_amount
    WHERE (SELECT SUM(points)
           FROM StudentCourse
           WHERE StudentCourse.student_login = Student.login) < v_avgPts;

    DELETE
    FROM Student
    WHERE account_balance < 0;

    COMMIT;

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
END;
/

