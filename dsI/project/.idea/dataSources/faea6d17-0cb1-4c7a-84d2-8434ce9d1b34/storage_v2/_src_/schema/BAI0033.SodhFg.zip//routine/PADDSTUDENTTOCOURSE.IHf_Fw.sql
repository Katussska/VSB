CREATE PROCEDURE PAddStudentToCourse(p_student_login Student.login%TYPE, p_course_code Course.code%TYPE,
                                                p_year INT) AS
    v_capacity INT;
    v_cnt      INT;
BEGIN
    SELECT capacity
    INTO v_capacity
    FROM Course
    WHERE code = p_course_code;

    SELECT COUNT(*)
    INTO v_cnt
    FROM StudentCourse
    WHERE course_code = p_course_code;

    IF v_cnt < v_capacity THEN
        INSERT INTO StudentCourse (student_login, course_code, year)
        VALUES (p_student_login, p_course_code, p_year);
    ELSE
        PPrint('Kurz je jiz plne obsazen.');
    END IF;
END;
/

