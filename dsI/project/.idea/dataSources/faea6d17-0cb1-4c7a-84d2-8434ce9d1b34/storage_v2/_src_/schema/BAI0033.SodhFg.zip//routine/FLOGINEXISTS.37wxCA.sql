CREATE FUNCTION FLoginExists(p_login Student.login%TYPE) RETURN BOOLEAN AS
    v_cnt INT;
BEGIN
    SELECT COUNT(*)
    INTO v_cnt
    FROM Student
    WHERE login = p_login;

    IF v_cnt > 0 THEN
        RETURN TRUE;
    ELSE
        RETURN FALSE;
    END IF;
END;
/

