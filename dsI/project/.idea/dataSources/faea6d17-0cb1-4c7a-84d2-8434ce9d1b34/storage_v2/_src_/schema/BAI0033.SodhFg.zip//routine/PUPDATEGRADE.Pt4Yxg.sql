CREATE PROCEDURE PUpdateGrade(p_grade Student.grade%TYPE, p_fname Student.fName%TYPE,
                                         p_lname Student.lName%TYPE, p_type VARCHAR) AS

    v_sql VARCHAR(100);
BEGIN
    v_sql := 'BEGIN PUpdateGrade' || p_type || '(:1, :2, :3); END;';
    EXECUTE IMMEDIATE v_sql USING p_grade, p_fname, p_lname;
END;
/

