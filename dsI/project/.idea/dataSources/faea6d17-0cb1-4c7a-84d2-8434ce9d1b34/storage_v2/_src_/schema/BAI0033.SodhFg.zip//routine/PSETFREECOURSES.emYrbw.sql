CREATE PROCEDURE PSetFreeCourses(p_login Student.login%TYPE) AS
    v_year  StudentCourse.year%TYPE;
    v_grade Student.grade%TYPE;
BEGIN
    v_year := EXTRACT(YEAR FROM CURRENT_TIMESTAMP);

    SELECT grade
    INTO v_grade
    FROM Student
    WHERE login = p_login;

    INSERT INTO StudentCourse(student_login, course_code, year)
    SELECT p_login, code, v_year
    FROM Course
    WHERE grade = v_grade
      AND (SELECT COUNT(*)
           FROM StudentCourse
           WHERE year = v_year
             AND StudentCourse.course_code = Course.code
             AND COALESCE(StudentCourse.points, 0) < 51) < Course.capacity;
END;
/

