CREATE FUNCTION FGetStudentScore(p_login Student.login%TYPE) RETURN NUMBER AS
    v_ptsReceived INT;
    v_ptsTotal    INT;
BEGIN
    SELECT COALESCE(SUM(points), 0), COUNT(*) * 100
    INTO v_ptsReceived, v_ptsTotal
    FROM StudentCourse
    WHERE student_login = p_login;

    RETURN v_ptsReceived / v_ptsTotal;
END;
/

