CREATE FUNCTION FGetNextLogin(p_lname VARCHAR) RETURN VARCHAR AS
    v_i     INT;
    v_login VARCHAR(6);
BEGIN
    v_i := 1;

    LOOP
        v_login := LOWER(SUBSTR(p_lname, 1, 3)) || LPAD(v_i, 3, '0');
        EXIT WHEN NOT FLoginExists(v_login);
        v_i := v_i + 1;
    END LOOP;

    RETURN v_login;
END;
/

