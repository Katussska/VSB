CREATE FUNCTION FGetCreateScript(p_tableName VARCHAR2)
    RETURN VARCHAR2
AS
    CURSOR c_columns IS SELECT *
                        FROM user_tab_columns
                        WHERE table_name = UPPER(p_tableName)
                        ORDER BY column_id;
    v_command VARCHAR2(1000);
BEGIN
    v_command := 'CREATE TABLE ' || UPPER(p_tableName) || '_OLD (';
    FOR one_column IN c_columns
        LOOP
            IF c_columns%ROWCOUNT > 1 THEN
                v_command := v_command || ',';
            END IF;
            v_command := v_command || ' ' || one_column.column_name || ' ' || one_column.data_type || '(' ||
                         one_column.data_length || ')';
        END LOOP;
    v_command := v_command || ')';

    RETURN v_command;
END;
/

