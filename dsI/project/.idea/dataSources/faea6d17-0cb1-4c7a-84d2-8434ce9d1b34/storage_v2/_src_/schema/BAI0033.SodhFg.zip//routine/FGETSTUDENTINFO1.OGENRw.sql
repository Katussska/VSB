CREATE FUNCTION FGetStudentInfo1(p_login Student.login%TYPE) RETURN VARCHAR AS
    v_ret VARCHAR(500);
BEGIN
    SELECT 'login = ' || login || '; fName = ' || fname || '; lname = ' || lname || '; email = ' || email ||
           '; grade = ' ||
           grade || '; date_of_birth = ' || date_of_birth || '; account_balance = ' || account_balance
    INTO v_ret
    FROM Student
    WHERE login = p_login;

    RETURN v_ret;
END;
/

