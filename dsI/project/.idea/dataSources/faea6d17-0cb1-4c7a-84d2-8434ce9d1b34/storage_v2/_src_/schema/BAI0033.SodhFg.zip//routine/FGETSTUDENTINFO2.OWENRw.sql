CREATE FUNCTION FGetStudentInfo2(p_login Student.login%TYPE, p_attributes VARCHAR) RETURN VARCHAR AS
    v_ret       VARCHAR(500);
    v_attribute VARCHAR(100);
    p_index     INT     := 1;
    p_indexOld  INT     := 1;
    p_exit      BOOLEAN := FALSE;
    v_selectSql VARCHAR(1000);
    v_querySql  VARCHAR(1000);
BEGIN
    v_selectSql := NULL;
    LOOP
        p_index := INSTR(p_attributes, ';', p_index);

        IF p_index = 0 THEN
            p_exit := TRUE;
            p_index := LENGTH(p_attributes) + 1;
        END IF;

        v_attribute := SUBSTR(p_attributes, p_indexOld, p_index - p_indexOld);

        IF v_selectSql IS NOT NULL THEN
            v_selectSql := v_selectSql || ' || ''; '' || ';
        END IF;

        v_selectSql := v_selectSql || '''' || v_attribute || ' = '' || ' || v_attribute;

        EXIT WHEN p_exit;

        p_index := p_index + 1;
        p_indexOld := p_index;
    END LOOP;

    v_querySql := 'SELECT ' || v_selectSql || ' FROM Student WHERE login = :1';

    EXECUTE IMMEDIATE v_querySql INTO v_ret USING p_login;

    RETURN v_ret;
END;
/

