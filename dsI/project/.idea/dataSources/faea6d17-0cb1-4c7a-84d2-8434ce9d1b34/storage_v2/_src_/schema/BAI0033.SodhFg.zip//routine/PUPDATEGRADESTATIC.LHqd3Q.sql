CREATE PROCEDURE PUpdateGradeStatic(p_grade Student.grade%TYPE, p_fname Student.fname%TYPE,
                                               p_lname Student.lname%TYPE) AS
BEGIN
    UPDATE Student
    SET grade = p_grade
    WHERE fname = p_fname
      AND lname = p_lname;
END;
/

