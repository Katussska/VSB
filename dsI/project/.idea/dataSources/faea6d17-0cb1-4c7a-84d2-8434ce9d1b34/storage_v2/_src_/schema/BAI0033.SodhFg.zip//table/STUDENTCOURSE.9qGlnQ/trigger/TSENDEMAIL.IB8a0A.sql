CREATE TRIGGER TSENDEMAIL
    AFTER INSERT
    ON STUDENTCOURSE
    FOR EACH ROW
DECLARE
    v_student_fname Student.fname%TYPE;
    v_student_lname Student.lname%TYPE;
    v_student_email Student.email%TYPE;
    v_teacher_fname Teacher.fname%TYPE;
    v_teacher_lname Teacher.lname%TYPE;
    v_course_name   Course.name%TYPE;
    v_subject       VARCHAR2(100);
    v_body          VARCHAR2(500);
BEGIN
    SELECT fname, lname, email
    INTO v_student_fname, v_student_lname, v_student_email
    FROM Student
    WHERE login = :new.student_login;

    SELECT Course.name, Teacher.fname, Teacher.lname
    INTO v_course_name, v_teacher_fname, v_teacher_lname
    FROM Teacher
             JOIN Course ON Teacher.login = Course.teacher_login
    WHERE Course.code = :new.course_code;

    v_subject := 'Prihlaseni ke kurzu ' || v_course_name;

    v_body := 'Vazeny studente ' || v_student_fname || ' ' || v_student_lname || ', dne ' ||
              TO_CHAR(CURRENT_TIMESTAMP, 'dd.mm.yyyy hh24:mi:ss') ||
              ' jste byl prihlasen do kurzu ' || v_course_name || '. Vyucujicim kurzu je ' || v_teacher_fname ||
              ' ' || v_teacher_lname || '.';

    PSendEMail(v_student_email, v_subject, v_body);
END;
/

