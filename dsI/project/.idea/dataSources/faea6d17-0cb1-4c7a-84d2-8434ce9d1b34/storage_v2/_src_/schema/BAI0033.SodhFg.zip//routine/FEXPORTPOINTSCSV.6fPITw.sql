CREATE FUNCTION FExportPointsCSV(p_year INT) RETURN VARCHAR AS
    v_ret VARCHAR(1024);
BEGIN
    v_ret := '';

    FOR c_student IN (
        SELECT Student.login, Student.fname, Student.lname, SUM(StudentCourse.points) AS pts
        FROM Student
                 JOIN StudentCourse ON Student.login = StudentCourse.student_login
        WHERE year = p_year
        GROUP BY Student.login, Student.fname, Student.lname
        ORDER BY pts DESC
        )
        LOOP
            v_ret := v_ret || c_student.login || ',' || c_student.fname || ',' || c_student.lname || ',' ||
                     c_student.pts || CHR(13) || CHR(10);
        END LOOP;

    RETURN v_ret;
END;
/

