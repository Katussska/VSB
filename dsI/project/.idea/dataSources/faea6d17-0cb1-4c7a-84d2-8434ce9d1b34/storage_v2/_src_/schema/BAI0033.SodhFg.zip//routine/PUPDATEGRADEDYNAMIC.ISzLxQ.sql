CREATE PROCEDURE PUpdateGradeDynamic(p_grade Student.grade%TYPE, p_fname Student.fname%TYPE,
                                                p_lname Student.lname%TYPE) AS

    v_whereStatement VARCHAR(100) := '(1=1)';
BEGIN
    IF p_fname IS NOT NULL THEN
        v_whereStatement := v_whereStatement || ' AND fname = ''' || p_fname || '''';
    END IF;

    IF p_lname IS NOT NULL THEN
        v_whereStatement := v_whereStatement || ' AND lname = ''' || p_lname || '''';
    END IF;

    EXECUTE IMMEDIATE ('
UPDATE Student
SET grade = :1
WHERE ' || v_whereStatement) USING p_grade;

END;
/

