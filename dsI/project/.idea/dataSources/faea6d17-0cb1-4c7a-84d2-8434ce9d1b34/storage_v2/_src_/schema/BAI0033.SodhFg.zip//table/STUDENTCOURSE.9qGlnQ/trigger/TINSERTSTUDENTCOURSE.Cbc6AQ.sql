CREATE TRIGGER TINSERTSTUDENTCOURSE
    BEFORE INSERT
    ON STUDENTCOURSE
    FOR EACH ROW
DECLARE
    v_capacity INT;
    v_cnt      INT;
    v_capacity_exceeded EXCEPTION;
BEGIN
    SELECT capacity
    INTO v_capacity
    FROM Course
    WHERE code = :new.course_code;

    SELECT COUNT(*)
    INTO v_cnt
    FROM StudentCourse
    WHERE course_code = :new.course_code;

    IF v_cnt >= v_capacity THEN
        RAISE v_capacity_exceeded;
    END IF;
END;
/

