#include "headers/encrypt.h"

void encrypt(char *str)
{
    ceaser_encrypt(str);
}
