#include "headers/encrypt.h"

void encrypt(char *str)
{
    xor_encrypt(str);
}
