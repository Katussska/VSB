#include "headers/encrypt.h"

void encrypt(char *str)
{
    no_encrypt(str);
}
