#include "headers/no_encrypt.h"

void no_encrypt()
{
    return;
}
