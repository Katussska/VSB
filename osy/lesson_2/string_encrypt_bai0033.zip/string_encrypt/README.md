```bash
make
LD_LIBRARY_PATH=./no ./main
LD_LIBRARY_PATH=./ceaser ./main
LD_LIBRARY_PATH=./xor ./main

```