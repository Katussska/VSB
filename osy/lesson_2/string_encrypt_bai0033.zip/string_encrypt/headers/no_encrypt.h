#include <stdio.h>
#include <string.h>

void no_encrypt();