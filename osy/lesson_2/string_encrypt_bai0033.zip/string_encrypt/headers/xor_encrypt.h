#include <stdio.h>
#include <string.h>

void xor_encrypt(char *str);