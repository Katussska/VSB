#include <stdio.h>
#include <string.h>

void ceaser_encrypt(char *str);