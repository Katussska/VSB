package lab;

public interface AbleToHit extends Collisionable {

}
