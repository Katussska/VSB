public interface IExpiration {
    int getExpiration();
}
