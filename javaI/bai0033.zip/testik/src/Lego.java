public class Lego extends PhysicalGoods {
    Lego(String n, double p, int s) {
        super("lego | " + n, p, s);
    }
}
